//
//  ViewController.swift
//  FinalApp
//
// Created by Lucas Snyder and Patrick Graham.

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func InteriorDIY(_ sender: Any) {
        performSegue(withIdentifier: "Interior DIY", sender: self)
    }
    @IBAction func ExteriorDIY(_ sender: Any) {
        performSegue(withIdentifier: "Exterior DIY", sender: self)
    }
    @IBAction func InteriorBackButton(_ sender: Any) {
        performSegue(withIdentifier: "Interior Back Button", sender: self)
    }
    @IBAction func ExteriorBackButton(_ sender: Any) {
        performSegue(withIdentifier: "Exterior Back Button", sender: self)
    }
    
    @IBAction func HowDIYWorks(_ sender: Any) {
        performSegue(withIdentifier: "Help", sender: self)
    }
    @IBAction func HelpBackButton(_ sender: Any) {
        performSegue(withIdentifier: "Help Back Button", sender: self)
    }
    
    }
